<template>
   <p>bookinfo</p>
</template>

<script>
export default {
   
}
</script>

<style>

</style>