<template>
 <div class="login">
   <div class="main">
      <!-- <h2>111111111</h2> -->
      <h2>图书后台管理</h2>
      <div class="inp">
        <input type="text">
        <span data-name="Username"></span>
      </div>
      <div class="inp">
        <input type="password">
        <span data-name="Password"></span>
      </div>
      <input class="btn" type="button" value="登录">
   </div>
 </div>
</template>

<script>
import $  from "jquery";
export default {
  data(){
    return{

    }
  },
  mounted(){
    $(".inp input").on("focus",function(){
      $(this).addClass("focus");
    })
    $(".inp input").on("blur",function(){
      if($(this).val()==""){
        $(this).removeClass("focus");
      }
    })

  }

}
</script>

<style scoped>
.login{
  width: 100%;
  height: 100%;
  background: linear-gradient(120deg,#5b6270,	#D3D3D3,#5b6270)
}
.main{
  width:350px;
  height: 400px;
  background: #F8F8FF;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%,-50%);
  padding: 20px 30px;
  box-sizing: border-box;
  border-radius: 10px;
  box-shadow: 2px 2px 5px #333333;
  transition: all 0.3s;
}
.main:hover{
  box-shadow: 5px 5px 15px #333333;
  transition: all 0.3s;
}
.main h2{
  font-size: 25px;
  text-align: center;
  margin: 30px
}
.main .inp{
  box-sizing: border-box;
  width: 100%;
  height: 40px;
  margin-bottom: 40px;
  position: relative;
  color: #F8F8FF;
}
.main .inp input{
  width: 100%;
  height: 100%;
  border: none;
  outline: none;
  background: none;
  padding: 0 5px;
  color: #515a6e;
  border-bottom: 2px solid #D3D3D3;
  z-index: 10;


}
/* .main .inp span{
} */
.main .inp span::before{
content: attr(data-name);
position: absolute;
top:50%;
left: 5px;
transform: translateY(-50%);
font-size: 18px;
  /* color: #515a6e;
   */
   color: #D3D3D3;
  transition: all 0.3s;
 

}
.main .inp span::after{
  content: " ";
  width: 0%;
  height: 2px;
  position: absolute;
  bottom: 0;
  left: 0;
  background: #515a6e;
  transition: all 0.3s;

}
 .main .inp .focus + span::before{
  content: attr(data-name);
  position: absolute;
  top:-20%;
  left: 5px;
  transform: translateY(-50%);
  font-size: 18px;
  transition: all 0.3s;
  color: #515a6e;
}
 .main .inp .focus + span::after{
  width: 100%;
  transition: all 0.3s;
}
.main .btn{
  display: block;
  width: 200px;
  height: 50px;
  color: #F8F8FF;
  font-size: 20px;
  margin: 0 auto;
  border: none;
  outline: none;
  background: linear-gradient(120deg,	#A9A9A9,#5b6270,#A9A9A9);
  background-size: 200%;
  font-weight: bold;
  transition: all 0.3s;
  cursor: pointer;
  box-shadow: 2px 2px 5px #333333;
  border-radius: 5px;
}
.main .btn:hover{
 background-position: right;
  box-shadow: 5px 5px 15px #333333;
  transition: all 0.3s;

}
</style>
