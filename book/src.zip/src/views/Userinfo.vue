<template>
  <p>userinfo</p>
</template>

<script>
import { getDemo } from "@/api/index"
export default {
  data(){
    return{

    }
  },
  mounted(){
    getDemo().then(res=>{
      console.log(res)
    })
  },


}
</script>

<style>

</style>