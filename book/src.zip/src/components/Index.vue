
<template>
  <div class="layout">
    <Layout style="height:100%">
      <Sider ref="side1" hide-trigger collapsible :collapsed-width="78" v-model="isCollapsed">
        <p class="title">
          <Icon type="ios-bookmarks" />
          <span>图书后台管理</span>
        </p>
        <Menu
          active-name="bookinfo"
          theme="dark"
          width="auto"
          :class="menuitemClasses"
          @on-select="topage"
        >
          <MenuItem name="bookinfo">
            <Icon type="ios-navigate"></Icon>
            <span>Option 1</span>
          </MenuItem>
          <MenuItem name="userinfo">
            <Icon type="ios-search"></Icon>
            <span>Option 2</span>
          </MenuItem>
          <MenuItem name="1-3">
            <Icon type="ios-settings"></Icon>
            <span>Option 3</span>
          </MenuItem>
        </Menu>
      </Sider>
      <Layout>
        <Header :style="{padding: 0}" class="layout-header-bar">
          <Icon
            @click.native="collapsedSider"
            :class="rotateIcon"
            :style="{margin: '0 20px'}"
            type="md-menu"
            size="24"
          ></Icon>
          <div class="user float">
            <Avatar
              src="https://i.loli.net/2017/08/21/599a521472424.jpg"
              icon="ios-person"
              size="large"
            />
            <Dropdown class="userinfo float" @on-click="userselect">
              <a href="javascript:void(0)" class="username">
                Admin
                <Icon type="ios-arrow-down"></Icon>
              </a>
              <DropdownMenu slot="list">
                <DropdownItem name="1">修改密码</DropdownItem>
                <DropdownItem name="2">基本资料</DropdownItem>
                <DropdownItem divided name="3">退出登录</DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </div>
        </Header>
        <Content :style="{margin: '15px', background: '#fff', minHeight: '260px'}">
          <router-view />
        </Content>
      </Layout>
    </Layout>
  </div>
</template>
<script>
import $ from "jquery";
export default {
  name: "Index",
  data() {
    return {
      isCollapsed: false
    };
  },
  computed: {
    rotateIcon() {
      return ["menu-icon", this.isCollapsed ? "rotate-icon" : ""];
    },
    menuitemClasses() {
      return ["menu-item", this.isCollapsed ? "collapsed-menu" : ""];
    }
  },
  watch: {
    isCollapsed(val) {
      if (val) {
        $(".title span").html("");
      } else {
        setTimeout(() => {
          $(".title span").html("图书后台管理")
        }, 100);
      }
    }
  },
  mounted() {},
  methods: {
    topage(name) {
      this.$router.push({ name: name });
    },
    userselect(name) {
      switch (name) {
        case "1":
          console.log("修改密码");
          break;
        case "2":
          console.log("基本资料");
          break;
        case "3":
          console.log("退出登录");
      }
    },
    collapsedSider() {
      this.$refs.side1.toggleCollapse();
    }
  }
};
</script>
<style scoped>
.layout {
  border: 1px solid #d7dde4;
  background: #f5f7f9;
  position: relative;
  border-radius: 4px;
  overflow: hidden;
  height: 100%;
}
.title {
  font-size: 25px;
  color: #fff;
  text-align: center;
  margin: 5px 0;
}
.title span {
  font-size: 20px;
  vertical-align: text-top;
  font-weight: bold;
}
.float {
  float: right;
}
.user .userinfo {
  margin: 0 20px;
}
.user .userinfo .username {
  color: #333;
}
.layout-header-bar {
  background: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
}
.layout-logo-left {
  width: 90%;
  height: 30px;
  background: #5b6270;
  border-radius: 3px;
  margin: 15px auto;
}
.menu-icon {
  transition: all 0.3s;
}
.rotate-icon {
  transform: rotate(-90deg);
}
.menu-item span {
  display: inline-block;
  overflow: hidden;
  width: 69px;
  text-overflow: ellipsis;
  white-space: nowrap;
  vertical-align: bottom;
  transition: width 0.2s ease 0.2s;
}
.menu-item i {
  transform: translateX(0px);
  transition: font-size 0.2s ease, transform 0.2s ease;
  vertical-align: middle;
  font-size: 16px;
}
.collapsed-menu span {
  width: 0px;
  transition: width 0.2s ease;
}
.collapsed-menu i {
  transform: translateX(5px);
  transition: font-size 0.2s ease 0.2s, transform 0.2s ease 0.2s;
  vertical-align: middle;
  font-size: 22px;
}
</style>