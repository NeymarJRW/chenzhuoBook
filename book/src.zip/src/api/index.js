import qs from 'qs'
import axios from 'axios'

axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'

var uri = 'http://localhost:3000'

const Http = (params, data) => {
  let option = {
    method: params.method || 'get',
    url: params.url,
    baseURL: uri,
    params: data,
    data: qs.stringify(data),
    withCredentials: true
  }
  if (params.method === 'post') {
    delete option.params
  } else {
    delete option.data
  }
  return new Promise((resolve, reject) => {
    axios(option)
      .then(res => {
        resolve(res.data)
      })
      .catch(err => {
        reject(err)
      })
  })
  
}

export const getDemo = data => {
  return Http({
    url: '/test/movie'
  })
}

export const postDemo = data => {
  return Http({
    method: 'post',
    url: ''
  }, data)
}