import axios from "axios";
import qs from "qs";
import { Promise } from "q";
import { resolve, reject } from "any-promise";

axios.defaluts.headers.post["Content-Type"] = 'application/x-www-form-urlencoded';
var uri="http://loaclhost";

const Http=(params,data)=>{
  let option={
    url:params.url,
    baseUrl:uri,
    method:params.method || "get",
    post_data:qs.stringify(data)
  }
  if(params.method!="post"){
    delete option.post_data
  }
  return new Promise((resolve,reject)=>{
    axios(option)
    .then(res=>{
        resolve(res.data)
    })
    .catch(err=>{
      reject(err)
    })
  })
}

export const Getlist=( )=>{
  return Http({
    url:"44444444444444444"
  })
}

export const Postdata=(data)=>{
  return Http({
    url:"ssssssssssssss",
    method:"post"
  },data)
}